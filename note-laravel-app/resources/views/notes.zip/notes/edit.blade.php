@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <h2>Edit Note</h2>

    @include('notes._form', [
        'action' => route('notes.update', $note),
        'method' => 'PUT',
        'note' => $note,
        'notebooks' => $notebooks
    ])
</div>
@endsection

@section('scripts')
@include('notes.partials._tinymce_script')
@endsection
