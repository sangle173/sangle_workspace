<!-- Load TinyMCE -->
<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

<script>
tinymce.init({
    selector: '.tiny-editor',
    plugins: 'image link media',
    toolbar: 'undo redo | styleselect | bold italic underline | alignleft aligncenter alignright alignjustify | outdent indent | link image media',
    images_upload_url: '{{ route('notes.uploadImage') }}',
    images_upload_credentials: true,
});
</script>