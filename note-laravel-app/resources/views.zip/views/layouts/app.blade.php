<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Laravel Notes App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

    <script>
        tinymce.init({
            selector: 'textarea.tinymce-editor',
            plugins: 'image link lists table',
            toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | outdent indent | link image',
            images_upload_url: '{{ route('notes.uploadImage') }}',
            automatic_uploads: true,
            images_upload_handler: function (blobInfo, success, failure) {
                let xhr = new XMLHttpRequest();
                xhr.open('POST', '{{ route('notes.uploadImage') }}');
                xhr.setRequestHeader('X-CSRF-TOKEN', '{{ csrf_token() }}');
                xhr.onload = function () {
                    if (xhr.status != 200) {
                        failure('HTTP Error: ' + xhr.status);
                        return;
                    }
                    let json = JSON.parse(xhr.responseText);
                    if (!json || typeof json.location != 'string') {
                        failure('Invalid JSON: ' + xhr.responseText);
                        return;
                    }
                    success(json.location);
                };
                let formData = new FormData();
                formData.append('file', blobInfo.blob(), blobInfo.filename());
                xhr.send(formData);
            }
        });
    </script>
</head>
<body class="container-fluid p-0">
    <div class="row m-0">
        <div class="col-3 border-end p-3 bg-light" style="height: 100vh; overflow-y: auto;">
            @include('partials.sidebar')
        </div>
        <div class="col-9 p-4">
            @yield('content')
        </div>
    </div>
</body>
</html>
