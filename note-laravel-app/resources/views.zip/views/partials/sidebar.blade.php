<h5>Notebooks</h5>
@foreach($notebooks as $notebook)
    <div>
        <a href="{{ route('notebooks.edit', $notebook) }}" class="d-block fw-bold">{{ $notebook->title }}</a>
        @foreach($notebook->notes as $note)
            <a href="{{ route('notes.edit', $note) }}" class="d-block ms-3">{{ $note->title }}</a>
        @endforeach
    </div>
@endforeach

<div class="mt-3">
    <a href="{{ route('notebooks.create') }}" class="btn btn-primary btn-sm w-100 mb-2">+ New Notebook</a>
    <a href="{{ route('notes.create') }}" class="btn btn-success btn-sm w-100">+ New Note</a>
</div>
