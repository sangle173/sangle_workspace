<form action="{{ $action }}" method="POST">
    @csrf
    @if($method === 'PUT')
        @method('PUT')
    @endif

    <div class="mb-3">
        <label class="form-label">Select Notebook</label>
        <select name="notebook_id" class="form-control" required>
            @foreach($notebooks as $nb)
                <option value="{{ $nb->id }}" 
                    {{ old('notebook_id', $note->notebook_id) == $nb->id ? 'selected' : '' }}>
                    {{ $nb->title }}
                </option>
            @endforeach
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Note Title</label>
        <input type="text" name="title" class="form-control" 
            value="{{ old('title', $note->title) }}" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Note Content</label>
        <textarea name="content" class="form-control tinymce-editor" rows="15">
            {{ old('content', $note->content) }}
        </textarea>
    </div>

    <button type="submit" class="btn btn-success">Save</button>
</form>
