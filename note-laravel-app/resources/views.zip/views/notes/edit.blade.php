@extends('layouts.app')

@section('content')
<h2>Edit Note</h2>

@include('notes._form', [
    'action' => route('notes.update', $note),
    'method' => 'PUT',
    'note' => $note,
    'notebooks' => $notebooks
])
@endsection
