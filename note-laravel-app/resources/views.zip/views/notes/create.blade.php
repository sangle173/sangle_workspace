@extends('layouts.app')

@section('content')
<h2>New Note</h2>

@include('notes._form', [
    'action' => route('notes.store'),
    'method' => 'POST',
    'note' => new \App\Models\Note(),
    'notebooks' => $notebooks
])
@endsection
