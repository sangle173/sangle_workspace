@extends('layouts.app')

@section('content')
<div class="d-flex justify-content-between mb-3">
    <h2>Notebooks</h2>
    <a href="{{ route('notebooks.create') }}" class="btn btn-primary">+ New Notebook</a>
</div>

<ul class="list-group">
    @foreach($notebooks as $notebook)
    <li class="list-group-item d-flex justify-content-between align-items-center">
        <a href="{{ route('notebooks.show', $notebook) }}">{{ $notebook->title }}</a>
        <div>
            <a href="{{ route('notebooks.edit', $notebook) }}" class="btn btn-sm btn-warning">Edit</a>
            <form action="{{ route('notebooks.destroy', $notebook) }}" method="POST" class="d-inline">
                @csrf @method('DELETE')
                <button onclick="return confirm('Delete this notebook?')" class="btn btn-sm btn-danger">Delete</button>
            </form>
        </div>
    </li>
    @endforeach
</ul>
@endsection
