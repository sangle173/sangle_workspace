<form action="{{ $action }}" method="POST">
    @csrf
    @if($method === 'PUT')
        @method('PUT')
    @endif

    <div class="mb-3">
        <label class="form-label">Notebook Title</label>
        <input type="text" name="title" class="form-control" 
            value="{{ old('title', $notebook->title) }}" required>
    </div>

    <button type="submit" class="btn btn-primary">Save</button>
</form>
