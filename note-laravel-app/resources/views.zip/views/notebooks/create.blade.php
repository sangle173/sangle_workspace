@extends('layouts.app')

@section('content')
<h2>New Notebook</h2>

@include('notebooks._form', [
    'action' => route('notebooks.store'),
    'method' => 'POST',
    'notebook' => new \App\Models\Notebook()
])
@endsection
