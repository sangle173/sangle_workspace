package com.example.local_cloud;

import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class SonosService {

    public String sendSoftwareUpdate(String ip, String updUrl) {
        try {
            String soapBody =
                    "<u:BeginSoftwareUpdate xmlns:u=\"urn:schemas-upnp-org:service:SystemProperties:1\">" +
                            "<UpdateURL>" + updUrl + "</UpdateURL>" +
                            "<Flags>9</Flags>" +
                            "</u:BeginSoftwareUpdate>";

            String soapEnvelope =
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                    "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                    "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                    "<s:Body>" + soapBody + "</s:Body></s:Envelope>";

            HttpURLConnection conn = (HttpURLConnection) new URL("http://" + ip + ":1400/DeviceProperties/Control").openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
            conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:SystemProperties:1#BeginSoftwareUpdate\"");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(soapEnvelope.getBytes(StandardCharsets.UTF_8));
            }

            return conn.getResponseCode() == 200 ? "✅ Success!" : "❌ Failed with code " + conn.getResponseCode();

        } catch (Exception e) {
            return "❌ Error: " + e.getMessage();
        }
    }

    public String rebootDevice(String ip) {
        try {
            // GET CSRF token from /reboot page
            URL getUrl = new URL("http://" + ip + ":1400/reboot");
            HttpURLConnection getConn = (HttpURLConnection) getUrl.openConnection();
            getConn.setRequestMethod("GET");

            Scanner scanner = new Scanner(getConn.getInputStream()).useDelimiter("\\A");
            String html = scanner.hasNext() ? scanner.next() : "";

            Matcher matcher = Pattern.compile("name=\"csrfToken\" value=\"([^\"]+)\"").matcher(html);
            if (!matcher.find()) return "❌ CSRF token not found";

            String token = matcher.group(1);

            // POST token back to /reboot
            URL postUrl = new URL("http://" + ip + ":1400/reboot");
            HttpURLConnection postConn = (HttpURLConnection) postUrl.openConnection();
            postConn.setRequestMethod("POST");
            postConn.setDoOutput(true);
            postConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            String payload = "csrfToken=" + URLEncoder.encode(token, "UTF-8");
            postConn.getOutputStream().write(payload.getBytes());

            return postConn.getResponseCode() == 200 ? "✅ Rebooted" : "❌ Failed (" + postConn.getResponseCode() + ")";
        } catch (Exception e) {
            return "❌ Reboot error: " + e.getMessage();
        }
    }

    public String renameDevice(String ip, String newName, String currentName) {
        try {
            String body =
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                    "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                    "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                    "<s:Body>" +
                    "<u:SetRoomName xmlns:u=\"urn:schemas-upnp-org:service:DeviceProperties:1\">" +
                    "<DesiredRoomName>" + newName + "</DesiredRoomName>" +
                    "<CurrentRoomName>" + currentName + "</CurrentRoomName>" +
                    "</u:SetRoomName>" +
                    "</s:Body></s:Envelope>";

            HttpURLConnection conn = (HttpURLConnection) new URL("http://" + ip + ":1400/DeviceProperties/Control").openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
            conn.setRequestProperty("SOAPACTION", "\"urn:schemas-upnp-org:service:DeviceProperties:1#SetRoomName\"");

            conn.getOutputStream().write(body.getBytes());

            return conn.getResponseCode() == 200 ? "✅ Renamed" : "❌ Rename failed (" + conn.getResponseCode() + ")";
        } catch (Exception e) {
            return "❌ Rename error: " + e.getMessage();
        }
    }
}
